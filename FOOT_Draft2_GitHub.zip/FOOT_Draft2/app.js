const REVIEW_KEY = "foot_draft2_reviews";
const CART_KEY = "foot_draft2_cart";

const STARTER_REVIEWS = [
  {
    id: "starter-1",
    productId: "shimano-25-maikuro-ii-7-2-4kg-2pc-spin",
    author: "Sam",
    email: "demo@example.com",
    rating: 5,
    title: "Really nice all-round rod",
    body: "Starter demo review — replace with a real review before launch.",
    experience: "Intermediate",
    fishingType: "Saltwater",
    date: new Date("2026-09-01T10:00:00").getTime(),
    hidden: false,
    reports: 0
  },
  {
    id: "starter-2",
    productId: "shimano-25-maikuro-ii-7-2-4kg-2pc-spin",
    author: "Maya",
    email: "demo@example.com",
    rating: 4,
    title: "Easy to cast",
    body: "Starter demo review — replace with a real review before launch.",
    experience: "Beginner",
    fishingType: "Both",
    date: new Date("2026-09-02T10:00:00").getTime(),
    hidden: false,
    reports: 0
  },
  {
    id: "starter-3",
    productId: "shimano-25-maikuro-ii-7-2-4kg-2pc-spin",
    author: "Tommy",
    email: "demo@example.com",
    rating: 5,
    title: "Great first setup",
    body: "Starter demo review — replace with a real review before launch.",
    experience: "Beginner",
    fishingType: "Freshwater",
    date: new Date("2026-09-03T10:00:00").getTime(),
    hidden: false,
    reports: 0
  }
];

let reviews = loadReviews();
let cart = JSON.parse(localStorage.getItem(CART_KEY) || "[]");
let activeFilter = "all";

function loadReviews() {
  const saved = localStorage.getItem(REVIEW_KEY);
  if (!saved) {
    localStorage.setItem(REVIEW_KEY, JSON.stringify(STARTER_REVIEWS));
    return [...STARTER_REVIEWS];
  }
  try { return JSON.parse(saved); } catch { return [...STARTER_REVIEWS]; }
}

function saveReviews() { localStorage.setItem(REVIEW_KEY, JSON.stringify(reviews)); }
function getProduct(id) { return PRODUCTS.find(p => p.id === id); }
function stars(n) { return "★".repeat(n) + "☆".repeat(5 - n); }
function money(v) { return typeof v === "number" ? `$${v.toFixed(2)}` : "Price TBA"; }
function formatDate(v) { return new Date(v).toLocaleDateString("en-AU", {day:"numeric",month:"short",year:"numeric"}); }
function escapeHTML(value) { return String(value).replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;"); }
function visibleReviews() { return reviews.filter(r => !r.hidden).sort((a,b) => b.date - a.date); }

function renderProducts() {
  const grid = document.getElementById("product-grid");
  if (!grid) return;
  const list = PRODUCTS.filter(p => activeFilter === "all" || p.audience.includes(activeFilter));
  grid.innerHTML = list.map(p => `
    <article class="product-card">
      <div class="product-art">
        <div class="product-badges"><span class="badge">${escapeHTML(p.brand)}</span><span class="badge pick">${escapeHTML(p.badge)}</span></div>
        <div class="rod-illustration"><div class="rod-handle"></div><div class="rod-reel"></div><div class="rod-shaft"></div></div>
      </div>
      <div class="product-card-body">
        <p class="product-category">${escapeHTML(p.category)}</p>
        <h3>${escapeHTML(p.name)}</h3>
        <p>${escapeHTML(p.description)}</p>
        <div class="spec-list">${p.specs.map(s => `<span>${escapeHTML(s)}</span>`).join("")}</div>
        <div class="product-card-bottom"><strong>${money(p.price)}</strong><a class="btn secondary" href="product.html?id=${encodeURIComponent(p.id)}">View FOOT page →</a></div>
      </div>
    </article>`).join("");
}

function setupFilters() {
  document.querySelectorAll(".filter").forEach(button => button.addEventListener("click", () => {
    activeFilter = button.dataset.category;
    document.querySelectorAll(".filter").forEach(b => b.classList.toggle("active", b === button));
    renderProducts();
  }));
  document.querySelectorAll("[data-filter]").forEach(button => button.addEventListener("click", () => {
    activeFilter = button.dataset.filter;
    document.querySelectorAll(".filter").forEach(b => b.classList.toggle("active", b.dataset.category === activeFilter));
    document.getElementById("shop")?.scrollIntoView({behavior:"smooth"});
    renderProducts();
  }));
}

function renderHomeReviews() {
  const list = document.getElementById("review-list");
  const summary = document.getElementById("review-summary");
  if (!list || !summary) return;
  const visible = visibleReviews();
  const avg = visible.length ? visible.reduce((s,r) => s + r.rating, 0) / visible.length : 0;
  summary.innerHTML = `<div class="review-summary-grid"><div class="rating-box"><strong class="rating-number">${avg ? avg.toFixed(1) : "—"}</strong><div class="stars">${avg ? stars(Math.round(avg)) : "☆☆☆☆☆"}</div><p>Based on ${visible.length} public review${visible.length === 1 ? "" : "s"}</p></div><div class="review-callout"><strong>Reviews are part of FOOT.</strong><p>See what other anglers think before choosing gear, then add your own experience.</p></div></div>`;
  list.innerHTML = visible.map(r => {
    const product = getProduct(r.productId);
    return `<article class="review-card"><div class="review-meta">${escapeHTML(r.author)} • ${escapeHTML(r.experience)} • ${escapeHTML(r.fishingType)} • ${formatDate(r.date)}</div><h3><span class="stars">${stars(r.rating)}</span> ${escapeHTML(r.title)}</h3><p>${escapeHTML(r.body)}</p><div class="review-footer"><a class="btn secondary" href="product.html?id=${encodeURIComponent(r.productId)}">View rod</a><button class="report" data-report="${escapeHTML(r.id)}" type="button">Report</button></div></article>`;
  }).join("");
}

function productPageId() { return new URLSearchParams(window.location.search).get("id"); }

function productRating(id) {
  const rows = visibleReviews().filter(r => r.productId === id);
  if (!rows.length) return `<span class="muted">No reviews yet</span>`;
  const avg = rows.reduce((s,r) => s + r.rating, 0) / rows.length;
  return `<span class="stars">${stars(Math.round(avg))}</span><strong>${avg.toFixed(1)}</strong><span class="muted">(${rows.length})</span>`;
}

function renderProductPage() {
  const container = document.getElementById("product-details");
  if (!container) return;
  const product = getProduct(productPageId());
  if (!product) {
    container.innerHTML = `<div class="not-found"><h1>Rod not found</h1><a class="btn primary" href="index.html#shop">Back to shop</a></div>`;
    return;
  }
  document.title = `${product.name} — FOOT`;
  container.innerHTML = `
    <div class="product-large-image">
      <div class="product-badges"><span class="badge">${escapeHTML(product.brand)}</span><span class="badge pick">${escapeHTML(product.badge)}</span></div>
      <div class="rod-illustration large"><div class="rod-handle"></div><div class="rod-reel"></div><div class="rod-shaft"></div></div>
    </div>
    <div class="product-info">
      <p class="eyebrow">${escapeHTML(product.brand)} • ${escapeHTML(product.category)}</p>
      <h1>${escapeHTML(product.name)}</h1>
      <div class="product-rating-link">${productRating(product.id)}<a href="#product-reviews">Read reviews</a></div>
      <p class="product-description">${escapeHTML(product.description)}</p>
      <div class="product-spec-grid">${product.specs.map(s => `<div><span>DETAIL</span><strong>${escapeHTML(s)}</strong></div>`).join("")}</div>
      <div class="why-foot"><p class="eyebrow">WHY FOOT PICKED IT</p><p>${escapeHTML(product.whyWePickedIt)}</p></div>
      <div class="best-for"><strong>Best for</strong>${product.bestFor.map(s => `<span>${escapeHTML(s)}</span>`).join("")}</div>
      <div class="purchase-box"><strong class="product-price">${money(product.price)}</strong><button class="btn primary" data-add-cart="${product.id}" type="button">Add to demo cart</button></div>
      <p class="source-note">${escapeHTML(product.sourceLabel)}. <a href="${escapeHTML(product.sourceUrl)}" target="_blank" rel="noopener">View source</a></p>
    </div>`;
  document.getElementById("product-review-button")?.addEventListener("click", () => openReviewModal(product.id));
  renderProductReviews(product.id);
}

function renderProductReviews(id) {
  const list = document.getElementById("product-review-list");
  const summary = document.getElementById("product-review-summary");
  if (!list || !summary) return;
  const rows = visibleReviews().filter(r => r.productId === id);
  const avg = rows.length ? rows.reduce((s,r) => s + r.rating, 0) / rows.length : 0;
  summary.innerHTML = `<div class="rating-box product-rating-box"><strong class="rating-number">${avg ? avg.toFixed(1) : "—"}</strong><div class="stars">${avg ? stars(Math.round(avg)) : "☆☆☆☆☆"}</div><p>${rows.length} review${rows.length === 1 ? "" : "s"}</p></div>`;
  list.innerHTML = rows.length ? rows.map(r => `<article class="review-card"><div class="review-meta">${escapeHTML(r.author)} • ${escapeHTML(r.experience)} • ${escapeHTML(r.fishingType)} • ${formatDate(r.date)}</div><h3><span class="stars">${stars(r.rating)}</span> ${escapeHTML(r.title)}</h3><p>${escapeHTML(r.body)}</p><button class="report" data-report="${escapeHTML(r.id)}" type="button">Report</button></article>`).join("") : `<div class="review-card">No public reviews yet. Be the first to review this rod.</div>`;
}

function populateReviewProducts(selected = "") {
  const select = document.getElementById("review-product");
  if (!select) return;
  select.innerHTML = PRODUCTS.map(p => `<option value="${p.id}" ${p.id === selected ? "selected" : ""}>${escapeHTML(p.brand)} — ${escapeHTML(p.name)}</option>`).join("");
}

function openReviewModal(selected = "") { populateReviewProducts(selected); document.getElementById("review-modal")?.classList.remove("hidden"); }
function closeReviewModal() { document.getElementById("review-modal")?.classList.add("hidden"); }

function setupReviewForm() {
  const form = document.getElementById("review-form");
  if (!form) return;
  form.addEventListener("submit", e => {
    e.preventDefault();
    const review = {
      id: `review-${Date.now()}`,
      productId: document.getElementById("review-product").value,
      author: document.getElementById("review-name").value.trim(),
      email: document.getElementById("review-email").value.trim().toLowerCase(),
      rating: Number(document.getElementById("review-rating").value),
      title: document.getElementById("review-title").value.trim(),
      body: document.getElementById("review-body").value.trim(),
      experience: document.getElementById("review-experience").value,
      fishingType: document.getElementById("review-type").value,
      date: Date.now(), hidden: false, reports: 0
    };
    if (!review.author || !review.email || !review.rating || !review.title || !review.body) {
      document.getElementById("review-message").textContent = "Please complete every field.";
      return;
    }
    reviews.push(review);
    saveReviews();
    renderHomeReviews();
    const id = productPageId();
    if (id) renderProductReviews(id);
    form.reset();
    document.getElementById("review-message").textContent = "Your review is now live in this browser.";
  });
}

function reportReview(id) {
  const review = reviews.find(r => r.id === id);
  if (!review) return;
  if (!confirm("Report this review? One report hides it immediately in Draft 2.")) return;
  review.hidden = true;
  review.reports = Number(review.reports || 0) + 1;
  saveReviews();
  renderHomeReviews();
  const idOnPage = productPageId();
  if (idOnPage) renderProductReviews(idOnPage);
  alert("Thanks. The review has been hidden from public view.");
}

function addToCart(id) {
  const p = getProduct(id);
  if (!p) return;
  cart.push(id);
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
  updateCartCount();
  alert(`${p.name} added to the demo cart.`);
}

function updateCartCount() { const el = document.getElementById("cart-count"); if (el) el.textContent = cart.length; }

function setupGlobalClicks() {
  document.addEventListener("click", e => {
    const report = e.target.closest("[data-report]");
    if (report) reportReview(report.dataset.report);
    const add = e.target.closest("[data-add-cart]");
    if (add) addToCart(add.dataset.addCart);
    if (e.target.matches("[data-close-modal]")) closeReviewModal();
  });
  document.getElementById("open-review")?.addEventListener("click", () => openReviewModal());
}

document.addEventListener("DOMContentLoaded", () => {
  setupFilters();
  renderProducts();
  renderHomeReviews();
  renderProductPage();
  setupReviewForm();
  setupGlobalClicks();
  updateCartCount();
});
