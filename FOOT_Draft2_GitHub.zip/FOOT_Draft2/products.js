/* FOOT Draft 2 product catalogue.
   One real Shimano rod is fully wired first so the product-page template can be tested before the catalogue grows.
   Product information is based on a current Australian retail listing; verify exact variant/price before commercial launch.
*/
const PRODUCTS = [
  {
    id: "shimano-25-maikuro-ii-7-2-4kg-2pc-spin",
    brand: "Shimano",
    name: "25 Maikuro II 7' 2–4kg 2pc Spin Rod",
    audience: ["Adult", "Teen"],
    category: "Light Spin",
    badge: "FOOT PICK",
    price: 129,
    specs: [
      "7 ft",
      "2–4kg",
      "2 piece",
      "Spinning",
      "Fuji O-Ring guides"
    ],
    description: "A versatile light-tackle spinning rod for anglers fishing inshore and estuary environments.",
    details: "The 25 Maikuro II range is described as a versatile option for Australian fishing environments. The listed model is a 7 ft, 2–4kg, two-piece spinning rod.",
    whyWePickedIt: "It gives FOOT a strong first example of an everyday, versatile rod rather than starting with an ultra-specialised setup.",
    bestFor: ["Estuary", "Inshore", "Light tackle"],
    sourceLabel: "Current Australian retail reference: Anaconda",
    sourceUrl: "https://www.anacondastores.com/en-au/p/shimano-25-maikuro-ii-7-2-4kg-2pc-spin-rod"
  }
];
