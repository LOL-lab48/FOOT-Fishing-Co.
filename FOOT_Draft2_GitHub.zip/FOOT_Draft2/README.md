# FOOT — Draft 2

**By anglers. For anglers.**

Draft 2 turns FOOT into a real store-style prototype while keeping the catalogue small enough to perfect the experience first.

## Files

- `index.html` — FOOT homepage, shop, review hub and about section
- `product.html` — reusable FOOT-made product page template
- `styles.css` — all visual styling
- `products.js` — product catalogue data
- `app.js` — filters, product pages, reviews, reporting and demo cart

## First real product

Draft 2 starts with the **Shimano 25 Maikuro II 7' 2–4kg 2pc Spin Rod**. The product page is built as a FOOT shortcut page, with a FOOT Pick, product information, specs, best-for tags, source reference and product-specific reviews.

The product facts in `products.js` are based on a current Australian retailer listing. Verify the exact variant, current price, stock, supplier/reseller rights and final specifications before any commercial launch.

## Review behaviour

- 3 starter reviews are included for testing.
- Reviews appear immediately in the current browser.
- One report hides a review immediately.
- Reviews are tied to a specific product.
- The home page shows reviews across the store.
- Each product page shows reviews for that rod only.

These reviews are currently stored in `localStorage`, so they are **not yet shared between visitors**. A real backend/database will be needed before launch.

## Next catalogue step

Once this first Shimano page is approved, the same product-page system can be used for the rest of the range without rebuilding the layout.
